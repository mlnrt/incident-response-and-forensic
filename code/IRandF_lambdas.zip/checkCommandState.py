
# MIT No Attribution

# Permission is hereby granted, free of charge, to any person obtaining a copy of this
# software and associated documentation files (the "Software"), to deal in the Software
# without restriction, including without limitation the rights to use, copy, modify,
# merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so.

# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
# PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
# HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

import boto3
import logging
import json
ssmclient = boto3.client('ssm')

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Isolate the instance from the network
def lambda_handler(event, context):

    command_to_check = event.get('command_to_check')
    if (command_to_check == "MemoryDump"):
        instance_to_check = event.get('instanceID')
    elif (command_to_check == "SnapshotForensicAnalysis") or  (command_to_check == "MemoryForensicAnalysis"):
        instance_to_check = event.get('ForensicInstanceId')
    commandID = event.get('commandID')
    
    response = ssmclient.get_command_invocation(
        CommandId=commandID,
        InstanceId=instance_to_check
    )
    logger.info("Checking the status of the system manager command " + commandID)
    logger.info("The response of the get_command_invocation is: " + json.dumps(response))
    event['COMMAND_STATUS'] = response['Status']
    return event
