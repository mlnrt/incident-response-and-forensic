
# MIT No Attribution

# Permission is hereby granted, free of charge, to any person obtaining a copy of this
# software and associated documentation files (the "Software"), to deal in the Software
# without restriction, including without limitation the rights to use, copy, modify,
# merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so.

# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
# PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
# HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

import boto3
import logging
import json
ec2client = boto3.client('ec2')

logger = logging.getLogger()
logger.setLevel(logging.INFO)


# Isolate the instance from the network
def lambda_handler(event, context):

    instanceID = event.get('instanceID')
    response = ec2client.describe_instance_status(
        InstanceIds=[
            instanceID,
        ],
        IncludeAllInstances=True
    )
    logger.info("Checking the status of the isolated instance " + instanceID)
    logger.info("The response of the describe_instance_status API is: " + json.dumps(response))
    if len (response['InstanceStatuses']) == 1:
        # There should only be one instance
        event['INSTANCE_STATUS'] = response['InstanceStatuses'][0]['InstanceState']['Name']
    else:
        logger.info("There was issue checking the status of the instance " + instanceID + ". Check the response of the describe_instance_status API call.")
        event['INSTANCE_STATUS'] = "failed to retrieve instance status"
    return event
