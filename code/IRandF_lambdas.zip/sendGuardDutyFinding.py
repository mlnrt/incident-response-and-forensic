# MIT No Attribution

# Permission is hereby granted, free of charge, to any person obtaining a copy of this
# software and associated documentation files (the "Software"), to deal in the Software
# without restriction, including without limitation the rights to use, copy, modify,
# merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so.

# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
# PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
# HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.


import boto3
import json
import logging
import os

from base64 import b64decode
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

client = boto3.client('s3')

HOOK_URL = os.environ['HookUrl']
# The Slack channel to send a message to stored in the slackChannel environment variable
SLACK_CHANNEL = os.environ['SlackChannel']
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    instanceID = event['instanceID']
    event_type = event['guard_duty_summary']['event-type']
    event_time = event['guard_duty_summary']['time']
    event_severity = event['guard_duty_summary']['severity']
    event_title = event['guard_duty_summary']['title']
    event_description = event['guard_duty_summary']['description']
    instance_dns_name = event['guard_duty_summary']['privateDnsName']
    instance_Private_ip_address = event['guard_duty_summary']['privateIpAddress']
    
    slack_message_text = formatMyMessage(instanceID, event_severity, event_time, event_title, event_description, instance_dns_name, instance_Private_ip_address)
    req = Request(HOOK_URL, json.dumps(slack_message_text).encode('utf-8'))
    try:
        response = urlopen(req)
        response.read()
        logger.info("Message posted to %s", SLACK_CHANNEL)
    except HTTPError as e:
        logger.error("Request failed: %d %s", e.code, e.reason)
    except URLError as e:
        logger.error("Server connection failed: %s", e.reason)
 
    return event

def formatMyMessage(instanceID, event_severity, event_time, event_title, event_description, instance_dns_name, instance_Private_ip_address):
    slack_message = {
        "attachments": [
            {
                "fallback": "Required plain-text summary of the attachment.",
                "color": "#b7121a",
                "title": "High Alert!! Guard Duty has reported a finding of severity: " + str(event_severity),
                "text": "",
                "fields":[{
                        "value": "Here is a summary of the finding:"
                    },
                    {
                        "value": "Time: " + event_time
                    },
                    {
                        "value": "Title: " + event_title
                    },
                    {
                        "value": "Description: " + event_description
                    },
                    {
                        "value": "Instance ID: " + instanceID
                    },
                    {
                        "value": "Instance DNS name: " + instance_dns_name
                    },
                    {
                        "value": "Instance private IP address: " + instance_Private_ip_address
                    }]
            }
        ]
    }
    return slack_message