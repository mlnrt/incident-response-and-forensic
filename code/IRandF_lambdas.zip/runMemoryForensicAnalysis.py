# MIT No Attribution

# Permission is hereby granted, free of charge, to any person obtaining a copy of this
# software and associated documentation files (the "Software"), to deal in the Software
# without restriction, including without limitation the rights to use, copy, modify,
# merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so.

# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
# PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
# HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

import boto3
import os
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)
ssmclient = boto3.client('ssm')

def lambda_handler(event, context):
    
    
    instanceID = event['instanceID']
    S3BucketName = os.environ['OUTPUT_S3_BUCKETNAME']
    S3BucketRegion = os.environ['OUTPUT_S3_BUCKETREGION']
    commands = ['#!/bin/bash',
                'printf -v date "%(%F)T" -1', 
                'sudo -i', 
                'EC2_INSTANCE_ID=$(ec2metadata --instance-id)',
                'KERNEL_VERSION=$(uname -r)',
                'KERNEL_VERSION_STR=$(uname -r | tr "." "_")',
                'aws s3 cp /mnt/forensics/' + instanceID + '-memory.lime s3://' + S3BucketName + '/incident-response/' + instanceID + '/' + instanceID + '-memory.lime',
                'cd /opt/volatility',
                'python vol.py -f /mnt/forensics/' + instanceID + '-memory.lime --profile=LinuxUbuntu-${KERNEL_VERSION_STR}x64 linux_psscan > /home/ubuntu/' + instanceID + '-psscan.txt',
                'aws s3 cp /home/ubuntu/' + instanceID + '-psscan.txt s3://' + S3BucketName +'/incident-response/' + instanceID + '/' + instanceID + '-psscan.txt',
                'python vol.py -f /mnt/forensics/' + instanceID + '-memory.lime --profile=LinuxUbuntu-${KERNEL_VERSION_STR}x64 linux_pslist > /home/ubuntu/' + instanceID + '-pslist.txt',
                'aws s3 cp /home/ubuntu/' + instanceID + '-pslist.txt s3://' + S3BucketName +'/incident-response/' + instanceID + '/' + instanceID + '-pslist.txt',
                'python vol.py -f /mnt/forensics/' + instanceID + '-memory.lime --profile=LinuxUbuntu-${KERNEL_VERSION_STR}x64 linux_pstree > /home/ubuntu/' + instanceID + '-pstree.txt',
                'aws s3 cp /home/ubuntu/' + instanceID + '-pstree.txt s3://' + S3BucketName +'/incident-response/' + instanceID + '/' + instanceID + '-pstree.txt'
                ]
    
    
    response = ssmclient.send_command(
            InstanceIds= [event.get('ForensicInstanceId')],
            DocumentName='AWS-RunShellScript',
            Parameters={
            'commands': commands,
            'executionTimeout': ['600'] # Seconds all commands have to complete in
            },
            Comment='SSM Command Execution',
            # sydney-summit-incident-response
            OutputS3Region=S3BucketRegion,
            OutputS3BucketName=S3BucketName,
            OutputS3KeyPrefix="incident-response/" + event.get('ForensicInstanceId')

        )
    logging.info(response)
    # Retrieve the Command ID
    event['commandID'] = response['Command']['CommandId']
    event['command_to_check'] = "MemoryForensicAnalysis"
    return event
