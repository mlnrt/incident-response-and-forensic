
# MIT No Attribution

# Permission is hereby granted, free of charge, to any person obtaining a copy of this
# software and associated documentation files (the "Software"), to deal in the Software
# without restriction, including without limitation the rights to use, copy, modify,
# merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so.

# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
# PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
# HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

import boto3
import os
import json
import logging
import uuid

logger = logging.getLogger()
logger.setLevel(logging.INFO)

forensic_step_function = os.environ['STEP_FUNCTION_ARN']

sfn = boto3.client('stepfunctions')

# Isolate the instance from the network
def lambda_handler(event, context):

    if event['detail']['resource']['resourceType'] == "Instance" :
        event_data={}
        event_type = event['detail-type']
        event_time = event['time']
        event_severity = event['detail']['severity']
        event_title = event['detail']['title']
        event_description = event['detail']['description']
        instanceID = event['detail']['resource']['instanceDetails']['instanceId']
        instance_dns_name = event['detail']['resource']['instanceDetails']['networkInterfaces'][0]['privateDnsName']
        instance_Private_ip_address = event['detail']['resource']['instanceDetails']['networkInterfaces'][0]['privateIpAddress']

        event_data['instanceID']=instanceID
        event_data['guard_duty_summary'] = {
                                    "event-type": event_type,
                                    "time": event_time,
                                    "severity": event_severity,
                                    "title": event_title,
                                    "description": event_description,
                                    "privateDnsName": instance_dns_name,
                                    "privateIpAddress": instance_Private_ip_address
                                    }
        event_data['wait_time'] = 60
                                    
        logging.info("step function input:" + json.dumps(event_data))
        
        response = sfn.start_execution(
            stateMachineArn=forensic_step_function,
            name='IncidentResponseFor-'+instanceID+"-"+str(uuid.uuid4())[:4],
            input=json.dumps(event_data)
        )

        logging.info("step function response:" + str(response))

        output="Step Function successfully invoked"
    else:
        output="The GuardDuty finding was not about an instance. No incident remediation action was triggered."
        logging.info(output)
    return output
